#!/bin/sh

set -ev

sudo apt-get update -qq
sudo apt-get install -qq libqt4-dev libqt4-opengl-dev libqglviewer-dev libeigen3-dev libsuitesparse-dev
